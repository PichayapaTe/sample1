// JavaScript Document

// Create a basket to collect items

function startApp() {


    $(document).on("pagecontainerbeforeshow", function(event, data) {

        // Handle check out page
        if (data.toPage[0].id == 'home') {



        }



        // Handle Product 1 page

        if (data.toPage[0].id == 'product_1') {

            // detect if check box in product page has changed
            
        }

        // Handle Product 2 page

        if (data.toPage[0].id == 'product_2') {

           
        }

        // Handle Product 3 page

        if (data.toPage[0].id == 'product_3') {

           
        }

    });
}

function setCheckOut(pageName, price, product_name, image_path) {

    // Add object to basket
    
    
}


function removeCheckOut(key) {
    
    // Remove item from basket with key
    delete basket[key];
    
}
